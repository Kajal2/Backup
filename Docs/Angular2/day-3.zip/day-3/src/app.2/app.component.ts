import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { GuestService, IGuest } from './guest.services';
import 'rxjs/add/operator/map'

@Component({
  selector: 'app-root',
  template:` <div> Hello from Angular JS 2 </div>
             <div>
                <ul *ngFor='let p of myguests'>
                    <li> {{p.name}} </li>
                </ul>
                
                <div *ngIf='myguests'>
                    <b> There are {{myguests.length}} guests </b>
                </div>

             </div>
   
             `,
  
})
export class GuestComponent implements OnInit, OnDestroy{
  private myguests: IGuest[];
  private errormessage: string="";
  constructor(@Inject (GuestService) private service:GuestService ) {
       
  }
  title = 'app';

  ngOnInit() {
    this.service.getAllGuests().subscribe( guests => this.myguests=guests, error=>this.errormessage=error);
    
  }
  ngOnDestroy() {
   
    
  }
}
