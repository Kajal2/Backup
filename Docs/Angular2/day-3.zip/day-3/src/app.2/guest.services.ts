import {Injectable,Inject} from '@angular/core';
import {Http,Response} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';

export interface IGuest {
    id: number,
    name:string,
    constactNumber:string;
}

@Injectable()
export class GuestService {
    url= 'http://localhost:4200/assets/guests.json';
    constructor(@Inject(Http) private http:Http) {

    }
    
    getAllGuests():Observable<IGuest[]> {
     
    return this.http.get(this.url)
       .map((response:Response)=><IGuest[]>response.json())
       .catch((error:any) => Observable.throw(error.json().error || 'server error'));
    }

}

