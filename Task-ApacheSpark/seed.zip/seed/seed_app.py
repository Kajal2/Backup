from flask import Blueprint
main = Blueprint('main', __name__)
import json
from seed_engine import RecommendationEngine

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

from flask import Flask, request

@main.route("/customer/<customer_id>", methods=["GET"])
def customer_info(customer_id):
    logger.debug("Customer Info %s", customer_id)
    customers = recommendation_engine.get_customer_info(customer_id)
    strjson="""{"CUSTOMER_ID":"%s","CUSTOMER_NAME":"%s","CUSTOMER_ADDRESS1":"%s","CUSTOMER_ADDRESS2":"%s","CUSTOMER_CITY":"%s","CUSTOMER_STATE":"%s","CUSTOMER_COUNTRY":"%s","CUSTOMER_ZIPCODE":"%s","sites":[ """%(customers[0][0],customers[0][1],customers[0][2],customers[0][3],customers[0][4],customers[0][5],customers[0][6],customers[0][7])
    strjson=strjson+"""]}"""
    return strjson



def create_app(spark_context, dataset_path):
    global recommendation_engine
    recommendation_engine = RecommendationEngine(spark_context, dataset_path)
    app = Flask(__name__)
    app.register_blueprint(main)
    return app
